const express = require('express');
const router = express.Router();
const log = require('../controller/Login_controller');


router.post("/api/login", log.login);

router.post("/api/forgetpassword",log.forget);
module.exports = router;